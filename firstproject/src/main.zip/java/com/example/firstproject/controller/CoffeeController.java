package com.example.firstproject.controller;

import com.example.firstproject.dto.CoffeeForm;
import com.example.firstproject.entity.Coffee;
import com.example.firstproject.repository.CoffeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@Slf4j
public class CoffeeController {

    @Autowired
    CoffeeRepository coffeeRepository;

    @GetMapping("/articles/cnew")
    public String newCoffeeForm() {
        return "articles/cnew";
    }


    @PostMapping("articles/createcoffee")
    public String createCoffeeForm(CoffeeForm form){
        Coffee coffee = form.toEntity();
        log.info(coffee.toString());

        Coffee saved = coffeeRepository.save(coffee);
        log.info(saved.toString());
        return "redirect:/articles/coffee" + saved.getId();
    }
    @GetMapping("/articles/coffee{id}")
    public String show(@PathVariable Long id, Model model){

        Coffee coffeeEntity = coffeeRepository.findById(id).orElse(null);

        model.addAttribute("coffee", coffeeEntity);
        return "articles/cshow";
    }

    @GetMapping("articles/cindex")
    public String index(Model model){
        List<Coffee> coffeeList = coffeeRepository.findAll();
        model.addAttribute("coffeeEntityList",coffeeList);

        return "articles/cindex";
    }



    @GetMapping("/articles/coffee{id}/cedit")
    public String coffeeEdit(@PathVariable Long id, Model model) {
        Coffee coffeeEntity = coffeeRepository.findById(id).orElse(null);
        model.addAttribute("coffeeEdit", coffeeEntity);
        return "articles/cedit";
    }
    @PostMapping("articles/coffeeupdate")
    public String update(CoffeeForm form){
        Coffee coffeeEntity = form.toEntity();

//        db에서 가져오기
        Coffee target = coffeeRepository.findById(coffeeEntity.getId()).orElse(null);

        if(target != null){
            coffeeRepository.save(coffeeEntity);
        }
        return "redirect:/articles/coffee" + coffeeEntity.getId();

    }
    @GetMapping("articles/coffee{id}/cdelete")
    public String delete(@PathVariable Long id){
        Coffee coffee = coffeeRepository.findById(id).orElse(null);
        if(coffee!=null){
            coffeeRepository.delete(coffee);
        }
        return "redirect:/articles/cindex";
    }
}
