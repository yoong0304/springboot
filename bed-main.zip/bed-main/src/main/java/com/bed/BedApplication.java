package com.bed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BedApplication {

	public static void main(String[] args) {
		SpringApplication.run(BedApplication.class, args);
	}

}
