package com.bed.exception;


public class MemberManageException extends RuntimeException {

    public MemberManageException(String message){
        super(message);
    }
}
