package com.bed.constant;

public enum Size {
    SS,QUEEN,KING


}
