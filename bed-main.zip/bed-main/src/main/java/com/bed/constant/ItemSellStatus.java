package com.bed.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
