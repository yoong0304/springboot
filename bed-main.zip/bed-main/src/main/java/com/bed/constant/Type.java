package com.bed.constant;

public enum Type {
    AC,EN,T_LC
}
