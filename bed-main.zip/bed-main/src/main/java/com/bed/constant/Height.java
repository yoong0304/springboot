package com.bed.constant;

public enum Height {
    H_150, H_160, H_170, H_180
}
