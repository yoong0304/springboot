package com.bed.constant;

public enum Color {
    WGB,BROWN,BLUE
}
