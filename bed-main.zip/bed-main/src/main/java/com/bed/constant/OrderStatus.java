package com.bed.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
