package com.bed.constant;

public enum ArticleType {
    NEWS, NOTI
}
