package com.bed.constant;

public enum Role {
//    USER, ADMIN
    ROLE_USER, ROLE_ADMIN
}
