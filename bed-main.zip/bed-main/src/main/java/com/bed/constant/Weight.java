package com.bed.constant;

public enum Weight {
    W_50, W_560, W_780, W_90
}
