package com.bed.constant;

public enum Age {
    AGE_10, AGE_230, AGE_450, AGE_60
}
