package com.bed.constant;

public enum AsFormStatus {
    CHECK, DELAY
}
