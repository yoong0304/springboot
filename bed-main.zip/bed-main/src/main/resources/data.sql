--소프트 매트리스
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(1, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_150', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(2, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_150', 'W_560', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(3, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_150', 'W_780', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(4, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_150', 'W_90', 'Soft1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(5, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_160', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(6, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_160', 'W_560', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(7, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_160', 'W_780', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(8, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_160', 'W_90', 'Soft1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(9, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_170', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(10, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_170', 'W_560', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(11, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_170', 'W_780', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(12, 'Regular', '레귤러매트리스', 'AGE_10', 'W', 'H_170', 'W_90', 'Regular1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(13, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'W', 'H_180', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(14, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_180', 'W_560', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(15, 'Soft', '소프트매트리스', 'AGE_10', 'W', 'H_180', 'W_780', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(16, 'Regular', '레귤러매트리스', 'AGE_10', 'W', 'H_180', 'W_90', 'Regular1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(17,  'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'M', 'H_150', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(18,  'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'M', 'H_150', 'W_560', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(19, 'Soft', '소프트매트리스', 'AGE_10', 'M', 'H_150', 'W_780', 'Soft2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(20, 'Regular', '레귤러매트리스', 'AGE_10', 'M', 'H_150', 'W_90', 'Regular2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(21,  'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'M', 'H_160', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(22, 'Soft', '소프트매트리스', 'AGE_10', 'M', 'H_160', 'W_560', 'Soft2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(23, 'Soft', '소프트매트리스', 'AGE_10', 'M', 'H_160', 'W_780', 'Soft2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(24, 'Regular', '레귤러매트리스', 'AGE_10', 'M', 'H_160', 'W_90', 'Regular2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(25, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_10', 'M', 'H_170', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(26, 'Soft', '소프트매트리스', 'AGE_10', 'M', 'H_170', 'W_560', 'Soft2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(27, 'Soft', '소프트매트리스', 'AGE_10', 'M', 'H_170', 'W_780', 'Soft2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(28, 'Soft', 'Regular', '레귤러매트리스', 'M', 'H_170', 'W_90', 'Regular2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(29, 'Premium Soft', '프리미엄 소프트매트리스','AGE_10', 'M', 'H_180', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(30, 'Regular', '레귤러매트리스', 'AGE_10', 'M', 'H_180', 'W_560', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(31, 'Regular', '레귤러매트리스', 'AGE_10', 'M', 'H_180', 'W_780', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(32, 'Regular', '레귤러매트리스', 'AGE_10', 'M', 'H_180', 'W_90', 'Regular2.jpg');


INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(33, 'Premium Soft', '프리미엄 소프트매트리스', 'AGE_230', 'W', 'H_150', 'W_50', 'PremiumSoft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(34, 'Soft', '소프트매트리스', 'AGE_230', 'W', 'H_150', 'W_560', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(35, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_150', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(36, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_150', 'W_90', 'Regular1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(37, 'Soft', '소프트매트리스', 'AGE_230', 'W', 'H_160', 'W_50', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(38,'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_160', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(39, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_160', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(40, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_160', 'W_90', 'Regular1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(41, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_170', 'W_50', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(42, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_170', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(43, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_170', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(44, 'Soft', '소프트매트리스', 'AGE_230', 'W', 'H_170', 'W_90', 'Soft1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(45, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_180', 'W_50', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(46, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_180', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(47, 'Regular', '레귤러매트리스', 'AGE_230', 'W', 'H_180', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(48, 'Hard', '하드매트리스', 'AGE_230', 'W', 'H_180', 'W_90', 'Hard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(49, 'Soft', '소프트매트리스', 'AGE_230', 'M', 'H_150', 'W_50', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(50, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_150', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(51, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_150', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(52, 'Hard', '하드매트리스', 'AGE_230', 'M', 'H_150', 'W_90', 'Hard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(53, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_160', 'W_50', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(54, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_160', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(55,'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_160', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(56, 'Hard', '하드매트리스', 'AGE_230', 'M', 'H_160', 'W_90', 'Hard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(57, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_170', 'W_50', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(58, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_170', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(59, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_170', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(60, 'Hard', '하드매트리스', 'AGE_230', 'M', 'H_170', 'W_90', 'Hard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(61, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_180', 'W_50',  'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(62, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_180', 'W_560',  'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(63, 'Regular', '레귤러매트리스', 'AGE_230', 'M', 'H_180', 'W_780',  'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(64,  'Hard', '하드매트리스', 'AGE_230', 'M', 'H_180', 'W_90', 'Hard1.jpg');


INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(65, 'Soft', '소프트매트리스', 'AGE_450', 'W', 'H_150', 'W_50', 'Soft1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(66, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_150', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(67, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_150', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(68, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_150', 'W_90', 'Hard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(69, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_160', 'W_50', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(70, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_160', 'W_560', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(71, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_160', 'W_780', 'Regular1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(72, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_160', 'W_90', 'Hard2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(73,'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_170', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(74, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_170', 'W_560', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(75, 'Regular', '레귤러매트리스', 'AGE_450', 'W', 'H_170', 'W_780', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(76, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_170', 'W_90', 'Hard2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(77, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_180', 'W_50', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(78, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_180', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(79, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_180', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(80, 'Hard', '하드매트리스', 'AGE_450', 'W', 'H_180', 'W_90', 'Hard2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(81, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_150', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(82, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_150', 'W_560','Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(83, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_150', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(84, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_150', 'W_90', 'Hard2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(85, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_160', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(86, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_160', 'W_560', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(87, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_160', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(88, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_160', 'W_90', 'Hard2.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(89, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_170', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(90, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_170', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(91,'Hard', '하드매트리스', 'AGE_450', 'M', 'H_170', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(92, 'Super Hard', '수퍼 하드 매트리스', 'AGE_450', 'M', 'H_170', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(93, 'Regular', '레귤러매트리스', 'AGE_450', 'M', 'H_180', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(94, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_180', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(95, 'Hard', '하드매트리스', 'AGE_450', 'M', 'H_180', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(96, 'Super Hard', '수퍼 하드 매트리스', 'AGE_450', 'M', 'H_180', 'W_90', 'SuperHard1.jpg');


INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(97, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_150', 'W_50', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(98, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_150', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(99,'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_150', 'W_780', 'SuperHard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(100, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_150', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(101, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_160', 'W_50', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(102,'Hard', '하드매트리스', 'AGE_60', 'W', 'H_160', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(103, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_160', 'W_780', 'SuperHard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(104, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_160', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(105, 'Regular', '레귤러매트리스', 'AGE_60', 'W', 'H_170', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(106, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_170', 'W_560', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(107, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_170', 'W_780', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(108, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_170', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(109, 'Regular', '레귤러매트리스', 'AGE_60', 'W', 'H_180', 'W_50', 'Regular2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(110, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_180', 'W_560', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(111, 'Hard', '하드매트리스', 'AGE_60', 'W', 'H_180', 'W_780', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(112, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'W', 'H_180', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(113, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_150', 'W_50', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(114, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_150', 'W_560', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(115, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_150', 'W_780', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(116, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'M', 'H_150', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(117, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_160', 'W_50', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(118,'Hard', '하드매트리스', 'AGE_60', 'M', 'H_160', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(119,'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'M', 'H_160', 'W_780', 'SuperHard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(120, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'M', 'H_160', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(121, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_170', 'W_50', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(122, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_170', 'W_560', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(123, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_170', 'W_780', 'Hard1.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(124, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'M', 'H_170', 'W_90', 'SuperHard1.jpg');

INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(125, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_180', 'W_50', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(126, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_180', 'W_560', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(127, 'Hard', '하드매트리스', 'AGE_60', 'M', 'H_180', 'W_780', 'Hard2.jpg');
INSERT INTO mattress(mat_id, title, content, age, gender, height, weight, image) VALUES(128, 'Super Hard', '수퍼 하드 매트리스', 'AGE_60', 'M', 'H_180', 'W_90', 'SuperHard1.jpg');












--레귤러 매트리스




