	$(function(){ //html /css 준비가 끝나면 실행해라
    setTimeout(function() {
         window.scrollTo(0, 500);
         document.getElementById("matInfo").style.opacity = 1;
              }, 500);

               });