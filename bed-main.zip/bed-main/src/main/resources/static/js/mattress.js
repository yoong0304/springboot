document.addEventListener("DOMContentLoaded", function() {
            var link1 = document.querySelector(".man");

                        link1.addEventListener("click", function(event) {
                            event.preventDefault();
                            link1.classList.toggle("active");
                        });

            var link2 = document.querySelector(".woman");

                        link2.addEventListener("click", function(event) {
                            event.preventDefault();
                            link2.classList.toggle("active");
                        });
            var link3 = document.querySelector(".ageCd10");

                        link3.addEventListener("click", function(event) {
                            event.preventDefault();
                            link3.classList.toggle("active");
                        });
            var link4 = document.querySelector(".ageCd30");

                        link4.addEventListener("click", function(event) {
                            event.preventDefault();
                            link4.classList.toggle("active");
                        });
            var link5 = document.querySelector(".ageCd50");

                        link5.addEventListener("click", function(event) {
                            event.preventDefault();
                            link5.classList.toggle("active");
                        });
            var link6 = document.querySelector(".ageCd60");

                        link6.addEventListener("click", function(event) {
                            event.preventDefault();
                            link6.classList.toggle("active");
                        });
            var link7 = document.querySelector(".w50");

                        link7.addEventListener("click", function(event) {
                            event.preventDefault();
                            link7.classList.toggle("active");
                        });
            var link8 = document.querySelector(".w60");

                        link8.addEventListener("click", function(event) {
                            event.preventDefault();
                            link8.classList.toggle("active");
                        });
            var link9 = document.querySelector(".w80");

                        link9.addEventListener("click", function(event) {
                            event.preventDefault();
                            link9.classList.toggle("active");
                        });
            var link10 = document.querySelector(".w90");

                        link10.addEventListener("click", function(event) {
                            event.preventDefault();
                            link10.classList.toggle("active");
                        });
            var link11 = document.querySelector(".h150");

                        link11.addEventListener("click", function(event) {
                            event.preventDefault();
                            link11.classList.toggle("active");
                        });
            var link12 = document.querySelector(".h160");

                        link12.addEventListener("click", function(event) {
                            event.preventDefault();
                            link12.classList.toggle("active");
                        });
            var link13 = document.querySelector(".h170");

                        link13.addEventListener("click", function(event) {
                            event.preventDefault();
                            link13.classList.toggle("active");
                        });
            var link14 = document.querySelector(".h180");

            link14.addEventListener("click", function(event) {
                event.preventDefault();
                link14.classList.toggle("active");
            });
        });