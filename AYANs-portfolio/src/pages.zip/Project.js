import React from 'react';

export default function Project() {
  return (
    <div>
      <h1>This is Project page</h1>
    </div>
  );
}
