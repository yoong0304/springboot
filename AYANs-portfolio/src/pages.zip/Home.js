import React from 'react';

export default function Home() {
  return (
    <div>
      <h1>This is Home Page</h1>
    </div>
  );
}
